import AddCard from './add-card';
export default AddCard;