import CardDetail from './card-detail';
export default CardDetail;