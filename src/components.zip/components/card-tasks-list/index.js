import CardTasksList from './card-tasks-list';
export default CardTasksList;